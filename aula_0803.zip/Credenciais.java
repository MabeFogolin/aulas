package crud;

public class Credenciais {

	public static final String user = "rm552669";
	public static final String pwd = "011102";
}
