package crud;

public class Credenciais {

	public static final String user = "rm000000";
	public static final String pwd = "sua senha aqui";
}
