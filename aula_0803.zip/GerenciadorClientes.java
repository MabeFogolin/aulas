package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;

/**
 * 
 * @author logonrmlocal
 * 
 * -> Driver JDBC - Java Database Connectivity 
 * -> Permite a execução de instruções do SQL (Vale para qualquer banco de dados relacional)
 * -> Pacote java.sql (biblioteca Java)
 * -> Classe DriverManager
 * -> Interfaces: Driver, Connection, Statement, PreparedStatement, ResultSet
 * 
 */


public class GerenciadorClientes {
	
	private String url = 
			"jdbc:oracle:thin:@oracle.fiap.com.br:1521:orcl";
	private Connection conn;
	
	/**
	 * Construtor do Gerenciador
	 * @throws SQLException
	 */
	public GerenciadorClientes() throws SQLException{
		
		//Criando um objeto do driver
		OracleDataSource ods = new OracleDataSource();
		//Configurando a URL
		ods.setURL(url);
		//Configurando o usuário
		ods.setUser(Credenciais.user);
		//Configurando a senha
		ods.setPassword(Credenciais.pwd);
		
		//Obtendo uma conexao
		conn = ods.getConnection();
		
	}
	
	//Metodo para inserir(Cliente)
	public boolean inserir(Cliente c) {
		String sql = "INSERT INTO clientes VALUES(?, ?, ?) ";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, c.getId());
			ps.setString(2, c.getNome());
			ps.setString(3, c.getSobrenome());
			ps.execute();
			
		} catch (SQLException e) {
			if(conn == null) {
				System.err.println("CONEXÃO NULA");
			} 				e.printStackTrace();
			return false;
		}finally {
			try {
				System.out.println("Fechando a conexão");
				conn.close();
			} catch (SQLException e) {
				System.err.println("Erro ao fechar a conexão");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
}
