package crud;

import java.sql.SQLException;

public class TestaBancoDados {
	
	public static void main(String[] args) throws SQLException {
		 
		GerenciadorClientes gc = new GerenciadorClientes();
		
		Cliente c1 = new Cliente(2, "Maria", "Fogolin");
		
		System.out.println(gc.inserir(c1) ? 
				"Cliente adicionado"
				: "Não foi possível adicionar o cliente");
		
		System.out.println(gc.inserir(new Cliente(3, "Beatriz", "Reis")) ? 
				"Cliente adicionado"
				: "Não foi possível adicionar o cliente");
		
		
	}

}
